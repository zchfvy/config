require("config.lazy")

vim.cmd('set notermguicolors')
vim.cmd('source ~/.config/nvim/vimrc')
