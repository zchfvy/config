return {
    {
        'pwntester/octo.nvim',
        requires = {
        'nvim-lua/plenary.nvim',
        'nvim-telescope/telescope.nvim',
        -- OR 'ibhagwan/fzf-lua',
        -- OR 'folke/snacks.nvim',
        'nvim-tree/nvim-web-devicons',
        },
        config = function ()
        require"octo".setup()
        end
    },
    {
        'dense-analysis/ale',
        config = function()
            -- Configuration goes here.
            local g = vim.g

            g.ale_ruby_rubocop_auto_correct_all = 1

            g.ale_linters = {
                ruby = {'rubocop', 'ruby'},
                lua = {'lua_language_server'}
            }
        end
    },
    -- 'vim-airline/vim-airline',

    'tpope/vim-abolish',
    'tpope/vim-dispatch',
    'tpope/vim-fugitive',
    'tpope/vim-obsession',
    'tpope/vim-repeat',
    'tpope/vim-speeddating',
    'tpope/vim-surround',
    'junegunn/vim-easy-align',

    'scrooloose/nerdtree',
    'Xuyuanp/nerdtree-git-plugin',
    'preservim/tagbar',
    'mbbill/undotree',

    'ervandew/supertab',
    { 'junegunn/fzf.vim', dependencies = { 'junegunn/fzf' } },
    'ctrlpvim/CtrlP.vim',
    {
      "folke/tokyonight.nvim",
      lazy = false,
      priority = 1000,
      opts = {},
    }
}
